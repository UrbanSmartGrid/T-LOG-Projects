Filelist:
ATtiny416_Xplained_Nano_layer_plots_release_rev4.pdf : PCB Layer Plots
BOM\Bill of Materials Print- ATtiny416_Xplained_Nano_release_rev4.xls : BOM, fitted components
ExportSTEP\ATtiny416_Xplained_Nano_release_rev4.step : 3D Model of PCBA
NC Drill\ATtiny416_Xplained_Nano_release_rev4.drl : Drill files, gerber
NC Drill\ATtiny416_Xplained_Nano_release_rev4.drr : Drill Files Report
ODB\ATtiny416_Xplained_Nano_release_rev4.zip : ODB++ Files
Pick Place\Pick Place for ATtiny416_Xplained_Nano_release_rev4.txt : Pick and Place file, component placement
Test Points\Assembly Testpoint Report for ATtiny416_Xplained_Nano_release_rev4.txt : Assembly Testpoint report, txt
Test Points\Assembly Testpoint Report for ATtiny416_Xplained_Nano_release_rev4.csv : Assembly Testpoint report, csv
NC Drill\ATtiny416_Xplained_Nano_-SlotHoles_release_rev4.txt : Drill files, ASCII-SlotHoles
NC Drill\ATtiny416_Xplained_Nano_-RoundHoles_release_rev4.txt : Drill files, ASCII-RoundHoles
ATtiny416_Xplained_Nano_design_documentation_release_rev4.pdf : Design Documentation with Bom
Gerber\ATtiny416_Xplained_Nano_release_rev4.G2 : Gerber files for POWER
Gerber\ATtiny416_Xplained_Nano_release_rev4.G1 : Gerber files for GND
Gerber\ATtiny416_Xplained_Nano_release_rev4.GBO : Gerber files for Bottom Overlay
Gerber\ATtiny416_Xplained_Nano_release_rev4.GBL : Gerber files for Bottom Layer
Gerber\ATtiny416_Xplained_Nano_release_rev4.GBS : Gerber files for Bottom Solder
Gerber\ATtiny416_Xplained_Nano_release_rev4.GTP : Gerber files for Top Paste
Gerber\ATtiny416_Xplained_Nano_release_rev4.GTS : Gerber files for Top Solder
Gerber\ATtiny416_Xplained_Nano_release_rev4.GM1 : Gerber files for Board (M1)
Gerber\ATtiny416_Xplained_Nano_release_rev4.GTL : Gerber files for Top Layer
Gerber\ATtiny416_Xplained_Nano_release_rev4.GTO : Gerber files for Top Overlay
NC Drill\ATtiny416_Xplained_Nano_release_rev4.LDP : Layer Pairs Definition
